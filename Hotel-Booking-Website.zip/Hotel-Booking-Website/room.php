<?php
include('db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>SUNRISE HOTEL</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resort Inn Responsive , Smartphone Compatible web template , Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen">
<link href="css/easy-responsive-tabs.css" rel='stylesheet' type='text/css'/>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
<link rel="stylesheet" href="css/jquery-ui.css" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/modernizr-2.6.2.min.js"></script>
<!--fonts-->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Federo" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
<!--//fonts-->
</head>
<body>
<!-- header -->
<div class="banner-top">
			<div class="social-bnr-agileits">
				<ul class="social-icons3">
								<li><a href="https://www.facebook.com/" class="fa fa-facebook icon-border facebook"> </a></li>
								<li><a href="https://twitter.com/" class="fa fa-twitter icon-border twitter"> </a></li>
								<li><a href="https://plus.google.com/u/0/" class="fa fa-google-plus icon-border googleplus"> </a></li> 
							</ul>
			</div>
			<div class="contact-bnr-w3-agile">
				<ul>
					<li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">INFO@SUNRISE.COM</a></li>
					<li><i class="fa fa-phone" aria-hidden="true"></i>+94 (65)222-44-55</li>	
					
								</form>
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	<div class="w3_navigation">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<h1><a class="navbar-brand" href="index.php">SUN <span>RISE</span><p class="logo_w3l_agile_caption">Your Dreamy Resort</p></a></h1>
				</div>
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="menu menu--iris">
						<ul class="nav navbar-nav menu__list">
							<li class="menu__item "><a href="index.php" class="menu__link">Home</a></li>
							<li class="menu__item"><a href="Aboutus.php" class="menu__link ">About Us</a></li>
							<li class="menu__item  menu__item--current "><a href="room.php" class="menu__link ">Rooms</a></li>
							<li class="menu__item"><a href="Event.php" class="menu__link ">Event & Dining</a></li>
							<li class="menu__item "><a href="Attraction.php" class="menu__link">Attraction</a></li>
							<li class="menu__item "><a href="contact.php" class="menu__link">Contact Us</a></li>

							

							
						</ul>
					</nav>
				</div>
				
			</nav>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="menu menu--iris">
						
						</ul>
					</nav>
				</div>
			</nav>

		</div>
	</div>
	<br>
   <br>
<!-- //header -->

      <link rel="stylesheet" href="css/style2.css" />
   </head>
   <body>
      <div class="section-container">
         <div class="columns image" style="background-image:url('images/services.jpg')">
            &nbsp;
         </div>
         <div class="columns content">
            <div class="content-container">
               <h5>Standard Room</h5>
               <p>
                 Our Standards rooms  offers an irressistables blend of syyle and comfort.Discover a peaceful envirenment from the hustel and bustle city complete with plush bedding,contemporary dector,and exceptional anmeties
</p>
<h4> Details </h5> <br>
<p> 1 room/200-220 Sq.ft/city view </p><br>
<p> Air Conditioned & Fan </p> <br>
<p> High speed WI-FI,phone,TV<br>
<div class="price-selet">
		<h3><span> Rate</span> $120</h3>	
<a href="admin/reservation.php" >Book Now</a>

</div>
				    ​

            </div>
         </div>
      </div>
      <br>
      <br>
      <div class="section-container">
         <div class="columns content">
            <div class="content-container">
               <h5> Dulex Room</h5>
               <p>
                  Our delux rooms offer King-sized beds with plush mattresses and luxurious lines.These large rooms features a corners setting area,a private bathroom with a walk-in shower,and delux fittings
</p>
<h4> Details </h4> <br>
<p> Air Conditioned </p> <br>
<p> Room Service,24 Hour </p> <br>
<p> High speed Wi-Fi, Phone,TV
               <p></p>               </p>
               <p>
               </p>
			   <div class="price-selet">
		<h3><span> Rate</span> $200</h3>	
<a href="admin/reservation.php" >Book Now</a>

</div>
            </div>
         </div>
         <br>
         <br>
         <div class="columns image" style="background-image:url('images/room-2.jpg')">
            &nbsp;
         </div>
      </div>
      <br>
      <br>
      <div class="section-container">
         <div class="columns image" style="background-image:url('images/room-3.jpg')">
            &nbsp;
         </div>
         <br>
         <br>
         <div class="columns content">
            <div class="content-container">
               <h5>Single Room</h5>
               <p>
In our single room offer one bed with luxirous lines. These room have the sufficient space for one person can comfertly live all facilities proided in this room

                  ​               </p>
				  <h4> Details </h4><br>
				  <p> WIFI Service</p><br>
				  <p> 24 Hours Room </P><br>
				  <p> Centrlised AC </p><br>
				  <div class="price-selet">
				  <h3><span> Rate</span> $150</h3>	


<a href="admin/reservation.php" >Book Now</a>

</div>
			
                  <div class="contact-bnr-w3-agile">
                     <ul>
               <p>
               </p>

            </div>

         </div>
      </div>
      <div>
</div>
      </div>
            </div> <br>
			<br>
			<div class="section-container">
         <div class="columns content">
            <div class="content-container">
               <h5>
				   Superior Room
			   </h5>
               <p>
                 Our superior AC rooms offer king sized bed with a plush matters and luxrious lines.These rooms features added space and sleeper sofa,capable of accommodating an extra two guestes and modern private bathroom with ashower and dulex fitting</p>
               <p></p>               </p>
			   <h4> Details</h4><br>
			   <p> 1 room /250 sp fit/city view<p><br>
 <p> Room service 24 hour<p><br>
 <p> News papaer delevered to room on request</p>
 <br>
 <div class="price-selet">
 <h3><span> Rate</span> $250</h3>	

<a href="admin/reservation.php" >Book Now</a>

</div>
               <p>
               </p><br>
			   <br>
<br>
<br>
            </div>
         </div>
         <br>
		 <br>
		 <br>
         <div class="columns image" style="background-image:url('images/signature-purple.jpg')">
 &nbsp;
 

         </div>
      </div>

      <br>
      <br>

            
   <br>
   <br>
      
      
<!-- /contact -->
			<div class="copy">
		        <p>© 2022 SUNRISE . All Rights Reserved | Design by <a href="index.php">SUNRISE</a> </p>
		    </div>
<!--/footer -->
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- contact form -->
<script src="js/jqBootstrapValidation.js"></script>

<!-- /contact form -->	
<!-- Calendar -->
		<script src="js/jquery-ui.js"></script>
		<script>
				$(function() {
				$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
				});
		</script>
<!-- //Calendar -->
<!-- gallery popup -->
<link rel="stylesheet" href="css/swipebox.css">
				<script src="js/jquery.swipebox.min.js"></script> 
					<script type="text/javascript">
						jQuery(function($) {
							$(".swipebox").swipebox();
						});
					</script>
<!-- //gallery popup -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- flexSlider -->
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
<script src="js/responsiveslides.min.js"></script>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider4").responsiveSlides({
							auto: true,
							pager:true,
							nav:false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
			</script>
		<!--search-bar-->
		<script src="js/main.js"></script>	
<!--//search-bar-->
<!--tabs-->
<script src="js/easy-responsive-tabs.js"></script>
<script>
$(document).ready(function () {
$('#horizontalTab').easyResponsiveTabs({
type: 'default', //Types: default, vertical, accordion           
width: 'auto', //auto or any width like 600px
fit: true,   // 100% fit in a container
closed: 'accordion', // Start closed if in accordion view
activate: function(event) { // Callback function if tab is switched
var $tab = $(this);
var $info = $('#tabInfo');
var $name = $('span', $info);
$name.text($tab.text());
$info.show();
}
});
$('#verticalTab').easyResponsiveTabs({
type: 'vertical',
width: 'auto',
fit: true
});
});
</script>
<!--//tabs-->
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	
	<div class="arr-w3ls">
	<a href="#home" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	</div>
<!-- //smooth scrolling -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
   </body>
</html>
